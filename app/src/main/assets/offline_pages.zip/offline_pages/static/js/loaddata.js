﻿//商品列表

function goodssearch(key) {
    key = key ? key : $("#txtSearch").val();
    if (goodlist) {
        goodlist.setUrl(apiUrl + "order/products", {
            storeUuid: stores[0].uuid,
            tenantUuid: userinfo.uuid,
            contractUuid: contracts[0].uuid,
            keyword: key
        }, true, false, true, true);
    }
    else {
        goodlist = $("#goodslist").paging({
            pagingUrl: apiUrl + "order/products",
            pagingType: "post",
            param: {
                storeUuid: stores[0].uuid,
                tenantUuid: userinfo.uuid,
                contractUuid: contracts[0].uuid,
                keyword: key
            },
            getData: function (source) {
                return source.body.records;
            },
            onBind: function (sourceData) {
                if (sessionStorage.goods) {
                    var resultData = JSON.parse(sessionStorage.getItem("goods")).data;
                    for (var i = 0; i < resultData.length; i++) {
                        if ($("#chk" + resultData[i].code).length > 0) {
                            $("#chk" + resultData[i].code).prop("checked", true);
                            $(".num" + resultData[i].code).text(resultData[i].goodsnum);
                            $("[name='v" + resultData[i].code + "']").val(resultData[i].goodsnum);
                            $("#singleCount" + resultData[i].code).text(resultData[i].price);
                            $("#singleCount" + resultData[i].code).attr("base", resultData[i].price);
                            //resultData.splice(i, 1);
                            //i--;
                        }
                    }
                    //sessionStorage.setItem("goods", JSON.stringify({ data: resultData }));
                    //sessionStorage.removeItem("goods");
                    countMoney();
                }
            }
        });
    }
}
//订单列表

function ordersearch() {
    var param = {
        storeUuid: stores[0].uuid,
        tenantUuid: userinfo.uuid,
        contracts: [contracts[0].uuid]
    }
    if (/((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)/.test($("#txtSearch").val())) {
        param.customerTelephone = $("#txtSearch").val()
    }
    else {
        param.customerName = $("#txtSearch").val()
    }
    if (orderslist) {
        orderslist.setUrl(apiUrl + "order/orders", param, true, false, true);
    }
    else {
        orderslist = $("#orderlist").paging({
            pagingUrl: apiUrl + "order/orders",
            param: param,
            pagingType: "post",
            getData: function (source) {
                return source.body.records;
            },
        })
    }
}
function delOrder(uuid, isDetail, version) {
    var delConfirm = $.tooltip({
        type: tooltiptype.confirm,
        autoShow: true,
        content: "您确定要删除么？",
        title: "删除确认",
        confirm: function () {
            $.extendget({
                url: apiUrl + "order/remove?id=" + uuid + "&version=" + version,
                type: "DELETE",
                success: function (data) {
                    if (data.success) {
                        if (isDetail) {
                            //window.location.href = "order.html";
                            window.SYP.pageLink("订单列表", "offline://order.html", -1);
                        }
                        else {
                            delConfirm.close();
                            $("#goods" + uuid).remove();
                        }
                    }
                }
            })
        }
    })
}
//新增订单
function bindSessionData() {
    if (sessionStorage.getItem("order")) {
        var datas = JSON.parse(sessionStorage.getItem("order")).data;
        $("[name='customerName']").val(datas.name);
        $("[name='customerTelephone']").val(datas.phone);
        $("[name='boothTelephone']").val(datas.managephone);
        $("[name='receiptAddress']").val(datas.address)
        $("[name='gift']").val(datas.gift);
        $("[name='voucher']").val(datas.voucher);
        $("[name='remark']").val(datas.remark);
        $("[value='" + datas.deliveryMode + "']").prop("checked", true);
        $("#install").prop("checked", datas.install);

    }
    else {
        $("#txtboothTelephone").val(userinfo.telephone)
    }
}
function save() {
    if ($("#orderform").validate()) {
        var goods = [];
        var activitys = [];
        var prom = false;
        $(".activeitem:checked").each(function (i, v) {
            activitys.push({
                activityId: $(this).val(),
                promotionUuid: $(this).attr("promotionUuid"),
                contract: {
                    code: $(this).attr("contractcode"),
                    name: $(this).attr("contractname"),
                    uuid: $(this).attr("contractuuid"),
                },
                serialNumber: 0,
                discountAmount: 0,
                name: $(this).attr("activityName")
            })
            prom = true;
        })
        var discountRate = $(".cell").first().val();
        for (var i = 0; i < sourceData.length; i++) {
            goods.push({
                uuid: sourceData[i].uuid,
                code: sourceData[i].code,
                name: sourceData[i].name,
                specification: sourceData[i].specification,
                model: sourceData[i].model,
                grade: sourceData[i].grade,
                qty: $("#txtqty" + sourceData[i].code).val(),
                unit: sourceData[i].unit,
                price: $("#singleCount" + sourceData[i].code).val(),
                originalPrice: sourceData[i].originalPrice,
                stdTotal: $("#singleCount" + sourceData[i].code).val() * $("#txtqty" + sourceData[i].code).val(),
                remark: sourceData[i].remark,
                returnQty: sourceData[i].returnQty,
                returnTotal: sourceData[i].returnTotal,
                pdtUuid: sourceData[i].uuid,
                payedTotal: 0
            })
        }
        if (goods.length == 0) {
            $.tooltip({
                content: "请先返回选择商品",
                autoShow: true,
                autoHide: true,
            })
            return false;
        }
        var params = {
            bizState: "ineffect",
            tenant: {
                uuid: userinfo.uuid,
                code: userinfo.code,
                name: userinfo.name
            },
            store: {
                uuid: stores[0].uuid,
                code: stores[0].code,
                name: stores[0].name
            },
            contract: {
                uuid: contracts[0].uuid,
                code: contracts[0].code,
                name: contracts[0].name
            },
            prom: prom,//是否促销？
            preActivities: activitys,
            lines: goods,
            fileIds: pics,
            frozenState: "unfrozen",
            discountRate: discountRate,
            orderDate: $("#orderdate").val() + " " + $("#ordertime").val()
        }
        if ($("#install").is("checked")) {
            params.install = $("#install").val()
        }
        $("[name='paymentCategory']:checked").val() == "deposit" ? params.preDeposit = $("#preDeposit").val() : false;
        $("#orderform").formSubmit({
            url: apiUrl + "order/save?time=" + get_now_full() + '&operator.id=100295001&operator.fullname=月星家居常州店&operator.namespace=yx',
            pparam: params,
            success: function (data) {
                if (data.success) {
					window.SYP.showAlertAndRedirectWithCleanStack("订单列表","提交成功", "offline://order.html");
                    //window.SYP.pageLink("订单列表", "offline://order.html", -1);
                    //window.location.href = "order.html";
                }
            }
        })
    }
}


//订单详情
function bindOrderDetail() {
    $("#detail").bindData({
        url: apiUrl + "order/" + getQueryString("id"),
        dataColumn: "body",
        onBind: function (data) {
            goodsData = data.lines;
            activityData = data.preActivities;
            picsData = { data: [] };
            for (var i = 0; i < data.fileIds.length; i++) {
                picsData.data[i] = { picid: data.fileIds[i] };
            }

            for (var i = 0; i < goodsData.length; i++) {
                goodsData[i].stdTotal1 = goodsData[i].stdTotal;
            }
            $("#goodslist").bindData({
                data: goodsData,
                dataColumn: "",
                onBind: function () {
                    $(".hidden").removeClass("hidden");
                }
            })
            if (picsData.data.length > 0) {
                $("#piclist").bindData({
                    data: picsData,
                    dataColumn: "data"
                })
            }
            else {
                $("#fileslist").remove();
            }
            $("#countnum").text(goodsData.length);
            $("#countmoney").text(data.stdTotal);
            if (activityData.length > 0) {
                $("#activitylist").bindData({
                    data: activityData,
                    dataColumn: ""
                })
            }
            else {
                $("#activityboard").remove();
            }

        }
    })
}
