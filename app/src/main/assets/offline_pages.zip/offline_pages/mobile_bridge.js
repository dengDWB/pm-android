MOBILEBRIDGEVERSION = '0.0.1'
String.prototype.trim = function() {
  return this.replace(/(^\s*)|(\s*$)/g,'');
}
window.onerror = function(e) {
  if(window.AndroidJSBridge && window.AndroidJSBridge.jsException) {
    window.AndroidJSBridge.jsException(e);
  }
  else {
    console.log(typeof(e));
    console.log(e);
  }
}
window.MobileBridgeWithAndroid = {
  version: function() {
    return 'android ' + MOBILEBRIDGEVERSION;
  },
  goBack: function() {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.goBackBehavior) === "function") {
      window.AndroidJSBridge.goBackBehavior(message);
    }
  },
  goToUrl: function(htmlName) {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.openOfflinePage) === "function") {
      window.AndroidJSBridge.openOfflinePage(htmlName);
    }
  }
}

window.MobileBridgeWithIOS = {
  version: function() {
    return 'ios ' + MOBILEBRIDGEVERSION;
  },
  connectWebViewJavascriptBridge: function(callback) {
    if(window.WebViewJavascriptBridge) {
      callback(WebViewJavascriptBridge)
    }
    else {
      document.addEventListener('WebViewJavascriptBridgeReady', function() {
        callback(WebViewJavascriptBridge)
      }, false)
    }
  },
  goBack: function(bannerName, link, objectId) {
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('goBackBehavior', {}, function(response) {});
    })
  },
  goToUrl: function(htmlName) {
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('openOfflinePage', {'htmlName': htmlName}, function(response) {});
    })
  }
}

window.MobileBridgeDefault = {
  version: function() {
    return 'default ' + MOBILEBRIDGEVERSION;
  },
  goBack: function(message) {
    window.history.back();
  },
  goToUrl: function(htmlName) {
    window.location.href = htmlName;
  }
}

var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
if(isiOS) {
  window.MobileBridge = window.MobileBridgeWithIOS;
} else if(isAndroid) {
  window.MobileBridge = window.MobileBridgeWithAndroid;
} else {
  window.MobileBridge = window.MobileBridgedefault;
}
