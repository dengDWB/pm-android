 /**
  * zepto插件：向左滑动删除动效
  * 使用方法：$('.itemWipe').touchWipe({itemDelete: '.item-delete'});
  * 参数：itemDelete  删除按钮的样式名
  */
 (function($) {
   $.fn.touchWipe = function(option) {
   var isMove = 0;
     var defaults = {
       itemDelete: '.item-delete', //删除元素
     };

     var isMoveAdd = function(){
       isMove += 1;
     }

     var isMoveZero = function(){
       isMove = 0;
     }


    /*  var abc = function(){
       return isMove
     }
     console.log(abc());*/
     var opts = $.extend({}, defaults, option); //配置选项

     var delWidth = $(opts.itemDelete).width();

     var initX; //触摸位置
     var moveX; //滑动时的位置
     var X = 0; //移动距离
     var objX = 0; //目标对象位置
     $(this).on('touchstart', function(event) {
       //event.preventDefault();
       var obj = this;
       initX = event.targetTouches[0].pageX;
       objX = (obj.style.WebkitTransform.replace(/translateX\(/g, "").replace(/px\)/g, "")) * 1;
       if (objX == 0) {
         $(this).on('touchmove', function(event) {
           //event.preventDefault();
           var obj = this;
           moveX = event.targetTouches[0].pageX;
           X = moveX - initX;
           if (X >= 0) {
             var abc = function(){
               isMoveAdd();
              }
             abc();

             obj.style.WebkitTransform = "translateX(" + 0 + "px)";
           } else if (X < 0) {
             var l = Math.abs(X);
             obj.style.WebkitTransform = "translateX(" + -l + "px)";
             if (l > delWidth) {
               l = delWidth;
               obj.style.WebkitTransform = "translateX(" + -l + "px)";
             }
           }
         });
       } else if (objX < 0) {
         $(this).on('touchmove', function(event) {
           var abc = function(){
               isMoveAdd();
              }
             abc();
           //event.preventDefault();
           var obj = this;
           moveX = event.targetTouches[0].pageX;
           X = moveX - initX;
           if (X >= 0) {
             var r = -delWidth + Math.abs(X);
             obj.style.WebkitTransform = "translateX(" + r + "px)";
             if (r > 0) {
               r = 0;
               obj.style.WebkitTransform = "translateX(" + r + "px)";
             }
           } else { //向左滑动
             obj.style.WebkitTransform = "translateX(" + -delWidth + "px)";
           }
         });
       }

     })

     $(this).on('touchend', function(event) {

       //event.preventDefault();
       var obj = this;
       objX = (obj.style.WebkitTransform.replace(/translateX\(/g, "").replace(/px\)/g, "")) * 1;

       var abc = function(){
       return isMove
      }
    /*   var num = abc();
      if(num>0){
        var zero = function(){
          isMoveZero();
        }
        zero();
      }else{

      } */
       if (objX > -delWidth / 2) {
         obj.style.transition = "all 0.2s";
         obj.style.WebkitTransform = "translateX(" + 0 + "px)";
         obj.style.transition = "all 0";
         objX = 0;
       } else {
         obj.style.transition = "all 0.2s";
         obj.style.WebkitTransform = "translateX(" + -delWidth + "px)";
         obj.style.transition = "all 0";
         objX = -delWidth;
       }

     })
     //链式返回
     return this;
   };

 })(Zepto);
 $(function() {

   function deleteMessage(id) {
     var rawID = id.replace('del', ''),
         $loading = document.getElementById("loading"),
         host = "123.56.91.131:8090",
         host1 = "localhost:4567";

     $loading.style.display = "block";
     $.ajax({
        type: "DELETE",
        url: "http://" + host + "/mobile/v2/message",
        data: {id: rawID},
        success: function(response, status, xhr) {
          $('.'+id).remove();
          $loading.style.display = "none";
        },
        error:function(XMLHttpRequest, textStatus, errorThrown) {
          $loading.style.display = "none";
          alert(errorThrown);
        }
      });
   }

  // $('.list-li').touchWipe({itemDelete: '.btn'});
  $('.detail').on('click', function(event) {
    //event.preventDefault();
    $('.content-detail').hide();
        $('.detail').hide();
    })
     $('.list-li').on('click',function(event) {
        var content = $(this).attr('_val');
      $('.content-detail').html(content);
      $('.content-detail').show();
      $('.detail').show();
    //alert()
   })
    $('.item-delete').on('click', function(event) {
      event.preventDefault();
      var r=confirm("确认删除？")
      var id = $(this).attr('_val');
      if(r){
        deleteMessage(id);
      }
      return false;
    })
 });
