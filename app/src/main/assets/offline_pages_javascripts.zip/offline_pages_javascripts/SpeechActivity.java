package com.intfocus.yonghuitest;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.SynthesizerListener;
import com.iflytek.cloud.ui.RecognizerDialog;
import com.iflytek.cloud.ui.RecognizerDialogListener;
import com.intfocus.yonghuitest.util.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;


public class SpeechActivity extends BaseActivity {

    private SpeechSynthesizer mTts;
    private RecognizerDialog mIatDialog;
    private SpeechRecognizer mIat;
    private EditText mResultText;
    private HashMap<String, String> mIatResults = new LinkedHashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speech);

        mIatDialog = new RecognizerDialog(this, mInitListener);

        mIat= SpeechRecognizer.createRecognizer(this, mInitListener);

        mResultText = (EditText) findViewById(R.id.iat_text);

        /*
        * 语音合成代码
        */
//        mTts= SpeechSynthesizer.createSynthesizer(this, null);
//        mTts.setParameter(SpeechConstant.VOICE_NAME, "xiaoyan");
//        mTts.setParameter(SpeechConstant.SPEED, "50");
//        mTts.setParameter(SpeechConstant.VOLUME, "50");
//        mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
//
//        mTts.startSpeaking("科大讯飞,让世界聆听我们的声音", mSynListener);

    }

    public void setParam() {
        // 清空参数
        mIat.setParameter(SpeechConstant.PARAMS, null);

        // 设置听写引擎
        mIat.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
        // 设置返回结果格式
        mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");
        mIat.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
        mIat.setParameter(SpeechConstant.ACCENT, "mandarin ");

        // 设置语音前端点:静音超时时间，即用户多长时间不说话则当做超时处理
        mIat.setParameter(SpeechConstant.VAD_BOS, "4000");

        // 设置语音后端点:后端点静音检测时间，即用户停止说话多长时间内即认为不再输入， 自动停止录音
        mIat.setParameter(SpeechConstant.VAD_EOS, "2000");

        mIat.setParameter(SpeechConstant.ASR_PTT, "1");

    }

    private RecognizerDialogListener mRecognizerDialogListener = new RecognizerDialogListener() {
        @Override
        public void onResult(RecognizerResult recognizerResult, boolean b) {
            Log.i("Speech1",recognizerResult.getResultString());
            printResult(recognizerResult);
        }

        @Override
        public void onError(SpeechError speechError) {

        }
    };

        /*
        * 语音合成代码
        */
//    private SynthesizerListener mSynListener = new SynthesizerListener() {
//        @Override
//        public void onSpeakBegin() {
//
//        }
//
//        @Override
//        public void onBufferProgress(int i, int i1, int i2, String s) {
//
//        }
//
//        @Override
//        public void onSpeakPaused() {
//
//        }
//
//        @Override
//        public void onSpeakResumed() {
//
//        }
//
//        @Override
//        public void onSpeakProgress(int i, int i1, int i2) {
//
//        }
//
//        @Override
//        public void onCompleted(SpeechError speechError) {
//            Log.d("Speech1", "成功1");
//        }
//
//        @Override
//        public void onEvent(int i, int i1, int i2, Bundle bundle) {
//
//        }
//    };

    private InitListener mInitListener = new InitListener() {

        @Override
        public void onInit(int code) {
            if (code != ErrorCode.SUCCESS) {
                Log.d("Speech1", "SpeechRecognizer init() code = " + code);
            }else {
                Log.d("Speech1","成功");
            }
        }
    };

    private void printResult(RecognizerResult results) {
        String text = JsonParser.parseIatResult(results.getResultString());

        String sn = null;
        // 读取json结果中的sn字段
        try {
            JSONObject resultJson = new JSONObject(results.getResultString());
            sn = resultJson.optString("sn");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        mIatResults.put(sn, text);

        StringBuffer resultBuffer = new StringBuffer();
        for (String key : mIatResults.keySet()) {
            resultBuffer.append(mIatResults.get(key));
        }

        mResultText.setText(resultBuffer.toString());
        mResultText.setSelection(mResultText.length());
    }

    public void startSpeech (View v) {
        mResultText.setText(null);
        mIatResults.clear();
        setParam();
        mIatDialog.setListener(mRecognizerDialogListener);

        mIatDialog.show();

    }

}
