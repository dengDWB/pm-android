MOBILEBRIDGEVERSION = '0.0.2'
String.prototype.trim = function() {
  return this.replace(/(^\s*)|(\s*$)/g,'');
}
window.onerror = function(e) {
  if(window.AndroidJSBridge && window.AndroidJSBridge.jsException) {
    window.AndroidJSBridge.jsException(e);
  }
  else {
    console.log(typeof(e));
    console.log(e);
  }
}
window.MobileBridgeWithAndroid = {
  version: function() {
    return 'android ' + MOBILEBRIDGEVERSION;
  },
  goBack: function() {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.goBackBehavior) === "function") {
      window.AndroidJSBridge.goBackBehavior(message);
    }
  },
  goToUrl: function(htmlName) {
    if(window.AndroidJSBridge && typeof(window.AndroidJSBridge.openOfflinePage) === "function") {
      window.AndroidJSBridge.openOfflinePage(htmlName);
    }
  },
  pageLink: function(bannerName, link, objectId) {
    console.log(window.MobileBridgeWithAndroid.version());
    console.log({'bannerName': bannerName, 'link': link, 'objectId': objectId});

    window.AndroidJSBridge.pageLink(bannerName, link, objectId);
  },
  showAlert: function(title, content) {
    console.log(window.MobileBridgeWithAndroid.version());
    console.log({'title': title, 'content': content});

    window.AndroidJSBridge.showAlert(title, content);
  },
  toggleShowBanner: function(state) {
    console.log(window.MobileBridgeWithAndroid.version());
    console.log({'toggleShowBanner state': state});

    window.AndroidJSBridge.toggleShowBanner(state);
  },
  appBadgeNum: function(type, num) {
    console.log(window.MobileBridgeWithAndroid.version());
    console.log({'type': type, 'num': num});

    window.AndroidJSBridge.appBadgeNum(type, num);
  }
};

window.MobileBridgeWithIOS = {
  version: function() {
    return 'ios ' + MOBILEBRIDGEVERSION;
  },
  connectWebViewJavascriptBridge: function(callback) {
    if(window.WebViewJavascriptBridge) {
      callback(WebViewJavascriptBridge)
    }
    else {
      document.addEventListener('WebViewJavascriptBridgeReady', function() {
        callback(WebViewJavascriptBridge)
      }, false)
    }
  },
  goBack: function(bannerName, link, objectId) {
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('goBackBehavior', {}, function(response) {});
    })
  },
  goToUrl: function(htmlName) {
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('openOfflinePage', {'htmlName': htmlName}, function(response) {});
    })
  },
  pageLink: function(bannerName, link, objectId) {
    console.log(window.MobileBridgeWithIOS.version());
    console.log({'bannerName': bannerName, 'link': link, 'objectId': objectId});
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('iosCallback', {'bannerName': bannerName, 'link': link, 'objectID': objectId}, function(response) {});
    })
  },
  showAlert: function(title, content) {
    console.log(window.MobileBridgeWithIOS.version());
    console.log({'title': title, 'content': content});
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('showAlert', {'title': title, 'content': content}, function(response) {});
    })
  },
  toggleShowBanner: function(state) {
    console.log(window.MobileBridgeWithIOS.version());
    console.log({'toggleShowBanner state': state});
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('toggleShowBanner', {'state': state}, function(response) {});
    })
  },
  appBadgeNum: function(type, num) {
    console.log(window.MobileBridgeWithIOS.version());
    console.log({'type': type, 'num': num});
    MobileBridge.connectWebViewJavascriptBridge(function(bridge){
      bridge.callHandler('appBadgeNum', {'type': type, 'num': num}, function(response) {});
    })
  }
};

window.MobileBridge = {
  version: function() {
    return 'default ' + MOBILEBRIDGEVERSION;
  },
  goBack: function(message) {
    window.history.back();
  },
  goToUrl: function(htmlName) {
    window.location.href = htmlName;
  },
  pageLink: function(bannerName, link, objectId) {
    console.log(window.MobileBridge.version());
    console.log({'bannerName': bannerName, 'link': link, 'objectId': objectId});

    window.location.href = link.replace('offline://', '');
  },
  showAlert: function(title, content) {
    console.log(window.MobileBridge.version());
    console.log({'title': title, 'content': content});

    alert(content);
  },
  toggleShowBanner: function(state) {
    console.log(window.MobileBridge.version());
    console.log({'toggleShowBanner state': state});
  },
  appBadgeNum: function(type, num) {
    console.log(window.MobileBridge.version());
    console.log({'type': type, 'num': num});
  }
};

var userAgent = navigator.userAgent;
var isAndroid = userAgent.indexOf('Android') > -1 || userAgent.indexOf('Adr') > -1; //android终端
var isiOS = !!userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
if(isiOS) {
  window.MobileBridge = window.MobileBridgeWithIOS;
}
if(isAndroid) {
  window.MobileBridge = window.MobileBridgeWithAndroid;
}

function goto_url(url) {
  console.log('goto_url: ' + url);
  if(url !== undefined && url !== null && url !== '' && $.trim(url) !== '') {
    MobileBridge.pageLink(url, 'offline://' + $.trim(url), 0);
  } else {
    alert('不支持该链接的跳转: ' + url);
  }
}
